const box = document.getElementsByTagName("h2");
for (i = 0, len = box.length; i < len; i++) {
    box[i].style.color = 'red';
  }
